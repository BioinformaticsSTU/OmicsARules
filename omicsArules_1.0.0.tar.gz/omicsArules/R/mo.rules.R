#' Applying Apriori for mining association rules for two omics datasets
#'
#' Disease initiation and progression often result from multiple aberrations at multiple regulation dimensions.
#' The co-occurrence pattern among significantly hyper(hypo)-methlylated genes and/or differentially 
#' expressed genes often imply potential mechanistic connections.In data mining field, the frequently
#' co-occurring items (called frequent item sets) and their associated relationship can be efficiently mined
#' via Apriori algorithm. Originated from market basket data analysis, association rules is a popular and
#' well established method for discovering strong relationship between frequent items. Here, mo.rules employs
#' the Apriori algorithm to mine association rules in two omics datasets. OmicsARules specially aimed at omics data
#' containing continuous variables, and further embedded a new rule-interestingness measure, Lamda3, to evaluate 
#' the association rules for identifying biologically significant patterns.
#'
#' @param bin1, bin2 namely two 0-1 binary matrices or data.frames from two forms of omics, where 1 reflects dysregulation of genes in tumors or other samples.
#' @param org1, org2 namely two original datasets containing continous variables, corresponding the bin1 and bin2 before dichotomization. 
#' @param other parameters, see \code{\link{so.rules}}.
#' @return an object of class rules. Notice that, only the rules containing genes (or other variables) from both two datasets are returned.
#' @details see \code{\link{so.rules}}
#' @examples
#' ## bin2, org2: namely a 0-1 binary dataset and the corresponding original data containing continous values 
#' ## assessing expression of 100 genes in 184 ESCC tumors and 11 normal tissues
#' res<-mo.rules(bin1,bin2,org1,org2,symbol=TRUE,row.g=TRUE,num_gene=20, supp=0.3, conf=0.8,maxl=3, minl=2)
#' res
#'
#' @references
#' 1. Hahsler, M., B. Grun, and K. Hornik, arules - A computational environment for mining association rules and frequent item sets. Journal of Statistical Software, 2005. 14(15).
#'
#' 2. Agrawal, R., T. Imielinski, and A. Swami, Mining association rules between sets of items in large databases. Proceedings of the 1993 ACM SIGMOD International Conference on Management of Data, 1993: p. 207-216.
#'
#' 3. Brin, S., et al., Dynamic itemset counting and implication rules for market basket data. Proceedings of the ACM SIGMOD International Conference on Management of Data, 1997: p. 255-264.
#'
#' 4. Pasquier, N., et al., Closed Set Based Discovery of Small Covers for Association Rules. Networking & Information Systems, 1999. 3(2): p. 349-377.
#'
#' 5. Zaki, M.J., et al., Parallel Algorithms for Discovery of Association Rules. Data Mining and Knowledge Discovery, 1997: p. 343-373.


mo.rules=function(bin1, org1, bin2, org2, symbol=TRUE, row.g=TRUE, num_gene=50, supp=0.3, conf=0.8, up.lift=2, down.lift=1.2, maxl=3, minl=1){

	for (pkg in c('arules', 'org.Hs.eg.db', 'GOSim')){
		if(requireNamespace(pkg,quietly=TRUE)==FALSE){
			stop(paste('The ',pkg,' package needed for this function to work. Please install it.'),
           call. = FALSE);
		}
	}

	if (row.g==TRUE){
		rna.p3=bin1[1:num_gene,]
		methy.p3=bin2[1:num_gene,]
	}else if (row.g==FALSE){
		rna.p3=t(bin1)[1:num_gene,]
		methy.p3=t(bin2)[1:num_gene,]
	}else{
		stop('Error: row.g should be logical')
	}
	
	ids.comm<-intersect(colnames(rna.p3),colnames(methy.p3));
	rna<-rna.p3[,match(ids.comm, colnames(rna.p3))];
	colnames(rna)<-ids.comm
	methy<-methy.p3[,match(ids.comm,colnames(methy.p3))]

	##convert symbol to entrezid
	if (symbol==TRUE){
		library('org.Hs.eg.db')
		symbol2id<-as.list(org.Hs.egSYMBOL2EG)
		genes.id.rna<-unlist(symbol2id[rownames(rna)]);
		length(genes.id.rna);
		genes.id.methy<-unlist(symbol2id[rownames(methy)]);
		length(genes.id.methy);				
	}else{
		genes.id.rna<-rownames(rna)
		genes.id.methy<-rownames(methy)
	}
	
	genes.id<-c(genes.id.rna,genes.id.methy);
	length(genes.id);
	
	library('GOSim');
	##calculate the whole gene similarity among genes included in the rules
	setOntology(ont = "BP", loadIC=TRUE, DIR=NULL);
	g.num.bp.rna<-getGeneFeatures(genes.id.rna, pca=FALSE, normalization=FALSE, verbose=FALSE);
	
	if (symbol==TRUE){
		genes.id.bp.rna<-genes.id.rna[match(rownames(g.num.bp.rna),as.numeric(genes.id.rna))];
		syms.bp.rna<-names(genes.id.bp.rna);
		rna.t<-rna[match(syms.bp.rna,rownames(rna)),];
		rna<-na.omit(rna.t);
	}else{
		genes.id.bp.rna<-genes.id.rna[match(rownames(g.num.bp.rna),as.numeric(genes.id.rna))];
		rna.t<-rna[match(genes.id.bp.rna,rownames(rna)),]
		rna<-na.omit(rna.t)
	}
	
	g.num.bp.methy<-getGeneFeatures(genes.id.methy, pca=FALSE, normalization=FALSE, verbose=FALSE);
	
	if (symbol==TRUE){
		genes.id.bp.methy<-genes.id.methy[match(rownames(g.num.bp.methy),as.numeric(genes.id.methy))];
		syms.bp.methy<-names(genes.id.bp.methy);
		methy.t<-methy[match(syms.bp.methy,rownames(methy)),];
		methy<-na.omit(methy.t);
	}else{
		genes.id.bp.methy<-genes.id.methy[match(rownames(g.num.bp.methy),as.numeric(genes.id.methy))];
		methy.t<-methy[match(genes.id.bp.methy,rownames(methy)),]
		methy<-na.omit(methy.t)
	}
	
	data<-rbind(rna,methy);
	rownames(data)<-c(paste(rownames(rna),'.1',sep=''),paste(rownames(methy),'.2',sep=''));

	##finding rules
	library("arules");
	data.trans<-as(t(data),'transactions') ;
	rules<-apriori(data.trans,parameter = list(support = supp, confidence = conf, maxlen=maxl, minlen=minl));
	rules.1<-inspect(rules);
	rules.2<-inspect(subset(rules,subset=lift>down.lift));
	rules.3<-NULL;
	for (i in 1:nrow(rules.2)){
		tmp.lhs<-strsplit(substr(rules.2[i,'lhs'],2,nchar(as.character(rules.2[i,'lhs']))-1),',')[[1]];
		tmp.rhs<-substr(rules.2[i,'rhs'],2,nchar(as.character(rules.2[i,'rhs']))-1)
		Z<-c(tmp.lhs,tmp.rhs);
		
		if (length(tmp.lhs)==1){
			len<-length(union(substr(tmp.lhs,nchar(tmp.lhs),nchar(tmp.lhs)),substr(tmp.rhs,nchar(tmp.rhs),nchar(tmp.rhs))));
		}else{
			len<-length(union(c(substr(tmp.lhs[1],nchar(tmp.lhs[1]),nchar(tmp.lhs[1])),substr(tmp.lhs[2],nchar(tmp.lhs[2]),nchar(tmp.lhs[2]))),
				substr(tmp.rhs,nchar(tmp.rhs),nchar(tmp.rhs))));
		}

		if (len==2){
			rules.3<-rbind(rules.3,rules.2[i,]);
		}
	}
	matrix.rules.3=as.matrix(rules.3);

	#######################calculate the new measure###################
	## read raw data
	if (row.g==TRUE){
		rna.org=org1
		methy.org=org2;
	}else if (row.g==FALSE){
		rna.org=t(org1)
		methy.org=t(org2);
	}else{
		stop('Error: row.g should be logical')
	}
	
	submethy.org<-methy.org[match(rownames(methy),rownames(methy.org)),match(colnames(methy),colnames(methy.org))];
	rownames(submethy.org)<-paste(rownames(submethy.org),'.2',sep='');

	subrna.org<-rna.org[match(rownames(rna),rownames(rna.org)),match(colnames(rna), colnames(rna.org))];
	colnames(subrna.org)<-colnames(subrna.org);
	rownames(subrna.org)<-paste(rownames(subrna.org),'.1',sep='');

	expr<-rbind(subrna.org,submethy.org);

	##nrow(subrules),in each rule, the correlation coefficients between these genes at two sides  
	my<-matrix(0,nrow=nrow(rules.3),ncol=4);
	colnames(my)<-c('support','confidence','lift','lamda3');

	matrix_all<-matrix(0,nrow=nrow(rules.3),ncol=6);
	colnames(matrix_all)<-c('lhs', 'rhs', 'support','confidence','lift','lamda3');

	for (m in 1:nrow(rules.3)){
		##calculate wcs and wcc,rule Z: A-C
		tmp.lhs<-strsplit(substr(rules.3[m,'lhs'],2,nchar(as.character(rules.3[m,'lhs']))-1),',')[[1]];
		tmp.rhs<-substr(rules.3[m,'rhs'],2,nchar(as.character(rules.3[m,'rhs']))-1);
		Z<-c(tmp.lhs,tmp.rhs);
		A<-tmp.lhs;
		C<-tmp.rhs;
		n.z<-length(Z);
		n.a<-length(A);
		n.c<-length(C);

		##embed genes coexpression,calculate wcs and wcc,rule Z: A-C
		if (length(tmp.lhs)==1 & length(tmp.rhs)>0){
			samples.ac<-which(data[which(rownames(data)==tmp.lhs),]==1 & data[which(rownames(data)==tmp.rhs),]==1);
			samples..<-	which(data[which(rownames(data)==tmp.lhs),]==0 & data[which(rownames(data)==tmp.rhs),]==0);

			lhs.ac<-as.numeric(expr[which(rownames(expr)==tmp.lhs),samples.ac]);
			lhs..<-as.numeric(expr[which(rownames(expr)==tmp.lhs),samples..]);

			rhs.ac<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples.ac]);
			rhs..<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples..]);
					
			others.ac<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2]),samples.ac];
			others..<-as.matrix(expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2]),samples..]);
				
			##cal tmp.lamda
			if (length(samples.ac)<=2 & length(samples..)>2){
				
				p.z..<-cor.test(lhs..,rhs..)$p.value;
					
				p.others..<-NULL;
				for (i in 1:nrow(others..)){
					p.others..<-c(p.others..,cor.test(lhs..,as.numeric(others..[i,]))$p.value);
				}
				p.others..<-median(p.others..,na.rm=TRUE);
				
				if (p.z..==0){
					p.z..=(10)^(-50);
				}
				
				if (p.others..==0){
					p.others..=(10)^(-50);
				}
				
				tmp.lamda<-abs(log10(p.z..))/abs(log10(p.others..));

			}else if (length(samples.ac)>2 & length(samples..)<=2){

				p.z.ac<-cor.test(lhs.ac,rhs.ac)$p.value;

				p.others.ac<-NULL;
				for (i in 1:nrow(others.ac)){
					p.others.ac<-c(p.others.ac,cor.test(lhs.ac,as.numeric(others.ac[i,]))$p.value);
				}
				p.others.ac<-median(p.others.ac,na.rm=TRUE);
				
				if (p.z.ac==0){
					p.z.ac=(10)^(-50);
				}
				if (p.others.ac==0){
					p.others.ac=(10)^(-50);
				}
				tmp.lamda<-abs(log10(p.z.ac))/abs(log10(p.others.ac));
				
			}else if (length(samples.ac)<=2 & length(samples..)<=2){
				tmp.lamda<-0;
			}else{
				p.z.ac<-cor.test(lhs.ac,rhs.ac)$p.value;
				p.z..<-cor.test(lhs..,rhs..)$p.value;
				p.others.ac<-NULL
				for (i in 1:nrow(others.ac)){
					p.others.ac<-c(p.others.ac,cor.test(lhs.ac,as.numeric(others.ac[i,]))$p.value);
				}
				p.others.ac<-median(p.others.ac,na.rm=TRUE);

				p.others..<-NULL
				for (i in 1:nrow(others..)){
					p.others..<-c(p.others..,cor.test(lhs..,as.numeric(others..[i,]))$p.value);
				}
				p.others..<-median(p.others..,na.rm=TRUE);
				if (p.z.ac==0){
					p.z.ac=(10)^(-50);
				}
				if (p.others.ac==0){
					p.others.ac=(10)^(-50);
				}
				if (p.z..==0){
					p.z..=(10)^(-50);
				}
				if (p.others..==0){
					p.others..=(10)^(-50);
				}
				tmp.lamda<-(abs(log10(p.z.ac))+abs(log10(p.z..)))/(abs(log10(p.others.ac))+abs(log10(p.others..)));
			}

		}else if (length(tmp.lhs)==2 & length(tmp.rhs)>0){

			samples.abc<-which(data[which(rownames(data)==tmp.lhs[1]),]==1 & data[which(rownames(data)==tmp.lhs[2]),]==1 & data[which(rownames(data)==tmp.rhs),]==1);
			samples..<-	which(data[which(rownames(data)==tmp.lhs[1]),]==0 & data[which(rownames(data)==tmp.lhs[2]),]==0 & data[which(rownames(data)==tmp.rhs),]==0);
			lhs1.abc<-as.numeric(expr[which(rownames(expr)==tmp.lhs[1]),samples.abc]);
			lhs2.abc<-as.numeric(expr[which(rownames(expr)==tmp.lhs[2]),samples.abc]);
			lhs1..<-as.numeric(expr[which(rownames(expr)==tmp.lhs[1]),samples..]);
			lhs2..<-as.numeric(expr[which(rownames(expr)==tmp.lhs[2]),samples..]);

			rhs.abc<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples.abc]);
			rhs..<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples..]);
			others.abc<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2] | rownames(expr)==Z[3]),samples.abc];
			others..<-as.matrix(expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2] | rownames(expr)==Z[3]),samples..]);

			##cal tmp.lamda
			if (length(samples.abc)<=2 & length(samples..)>2){
				p.z1..<-cor.test(lhs1..,rhs..)$p.value;		
				p.z2..<-cor.test(lhs2..,rhs..)$p.value;
				p.others1..<-NULL;
				for (i in 1:nrow(others..)){
					p.others1..<-c(p.others1..,cor.test(lhs1..,as.numeric(others..[i,]))$p.value);
				}
				p.others1..<-median(p.others1..,na.rm=TRUE);
				p.others2..<-NULL;
				for (i in 1:nrow(others..)){
					p.others2..<-c(p.others2..,cor.test(lhs2..,as.numeric(others..[i,]))$p.value);
				}
				p.others2..<-median(p.others2..,na.rm=TRUE);
			
				if (p.z1..==0){
					p.z1..=(10)^(-50);
				}
				
				if (p.others1..==0){
					p.others1..=(10)^(-50);
				}
				
				if (p.z2..==0){
					p.z2..=(10)^(-50);
				}
				
				if (p.others2..==0){
					p.others2..=(10)^(-50);
				}

				tmp.lamda<-(abs(log10(p.z1..))+abs(log10(p.z2..)))/(abs(log10(p.others1..))+abs(log10(p.others2..)));
			
			}else if (length(samples.abc)>2 & length(samples..)<=2){
				p.z1.abc<-cor.test(lhs1.abc,rhs.abc)$p.value;
				p.z2.abc<-cor.test(lhs2.abc,rhs.abc)$p.value;
				p.others1.abc<-NULL;
				for (i in 1:nrow(others.abc)){
					p.others1.abc<-c(p.others1.abc,cor.test(lhs1.abc,as.numeric(others.abc[i,]))$p.value);
				}
				p.others1.abc<-median(p.others1.abc,na.rm=TRUE);

				p.others2.abc<-NULL;
				for (i in 1:nrow(others..)){
					p.others2.abc<-c(p.others2.abc,cor.test(lhs2.abc,as.numeric(others.abc[i,]))$p.value);
				}
				p.others2.abc<-median(p.others2.abc,na.rm=TRUE);

				if (p.z1.abc==0){
					p.z1.abc=(10)^(-50);
				}
				if (p.others1.abc==0){
					p.others1.abc=(10)^(-50);
				}
				if (p.z2.abc==0){
					p.z2.abc=(10)^(-50);
				}
				if (p.others2.abc==0){
					p.others2.abc=(10)^(-50);
				}
				tmp.lamda<-(abs(log10(p.z1.abc))+abs(log10(p.z2.abc)))/(abs(log10(p.others1.abc))+abs(log10(p.others2.abc)));
			
			}else if (length(samples.abc)<=2 & length(samples..)<=2){
				tmp.lamda<-0;
			}else{
				p.z1.abc<-cor.test(lhs1.abc,rhs.abc)$p.value;
				p.z2.abc<-cor.test(lhs2.abc,rhs.abc)$p.value;
				p.z1..<-cor.test(lhs1..,rhs..)$p.value;
				p.z2..<-cor.test(lhs2..,rhs..)$p.value;
				p.others1.abc<-NULL;
				for (i in 1:nrow(others.abc)){
					p.others1.abc<-c(p.others1.abc,cor.test(lhs1.abc,as.numeric(others.abc[i,]))$p.value);
				}
				p.others1.abc<-median(p.others1.abc);
				p.others2.abc<-NULL;
				for (i in 1:nrow(others..)){
					p.others2.abc<-c(p.others2.abc,cor.test(lhs2.abc,as.numeric(others.abc[i,]))$p.value);
				}
				p.others2.abc<-median(p.others2.abc);
				p.others1..<-NULL;
				for (i in 1:nrow(others..)){
					p.others1..<-c(p.others1..,cor.test(lhs1..,as.numeric(others..[i,]))$p.value);			
				}	
				p.others1..<-median(p.others1..,na.rm=TRUE);
				p.others2..<-NULL;
				for (i in 1:nrow(others..)){
					p.others2..<-c(p.others2..,cor.test(lhs2..,as.numeric(others..[i,]))$p.value);
				}
				p.others2..<-median(p.others2..,na.rm=TRUE);
				
				if (p.z1.abc==0){
					p.z1.abc=(10)^(-50);
				}
				if (p.z2.abc==0){
					p.z2.abc=(10)^(-50);
				}
				if (p.z1..==0){
					p.z1..=(10)^(-50);
				}
				if (p.z2..==0){
					p.z2..=(10)^(-50);
				}
				if (p.others1.abc==0){
					p.others1.abc=(10)^(-50);
				}
				if (p.others2.abc==0){
					p.others2.abc=(10)^(-50);
				}
				if (p.others1..==0){
					p.others1..=(10)^(-50);
				}
				if (p.others2..==0){
					p.others2..=(10)^(-50);
				}
				tmp.lamda<-(abs(log10(p.z1.abc))+abs(log10(p.z2.abc))+abs(log10(p.z1..))+abs(log10(p.z2..)))/(abs(log10(p.others1.abc))+abs(log10(p.others2.abc))+abs(log10(p.others1..))+abs(log10(p.others2..)));
			}

		}else if (length(tmp.lhs)==0 | length(tmp.rhs)==0){
			tmp.lamda<-0;
		}
		my[m,]<-c(rules.3[m,'support'],rules.3[m,'confidence'],rules.3[m,'lift'],tmp.lamda);
		matrix_all[m,]=c(matrix.rules.3[m,'lhs'],matrix.rules.3[m,'rhs'], my[m,]);
	}
	return(matrix_all);

}








