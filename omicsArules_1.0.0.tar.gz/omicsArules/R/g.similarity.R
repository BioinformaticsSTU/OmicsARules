#' Functional annotation of association rules based on The Gene Oncology database
#'
#' Genes included in one association rule are supposed to tend to be functionally related. Here, in view of the
#' Gene Oncology (GO) database, functional similarity of genes in the same association rules was claculated.
#'
#' @param matrix_all a matrix returned by mo.rules or so.rules.
#' @param symbol logical. If genes included in rules are gene symbols but not entrez IDs?
#' @return a numeric vector. Each value specifies the gene similarity assessed over one rule.
#'
#' @details Biological connection between the gene(s) on the left side and the one on the right side of association rules is
#' evaluated on the basis of GO. Here in view of GO, Gene similarity in these rules is calculated.
#' This function calls R-package 'GOSim' \code{\link[GOSim]{getGeneSim}} to evaluate the similarity of genes on each side of an association rule
#' based on the similarities between the annotated GO terms. The method to calculate the pairwise functional similarity between genes
#' is 'funSimMax', that is the maximum pair-wise GO term similarity. other default parameters in\code{\link[GOSim]{getGeneSim}}  are used .
#'
#' @note If the genes included in rules are gene symbols, conversion of symbols into entrez IDs should be performed before calculating gene similarity.
#' Here, R-package 'org.Hs.eg.db' embedded in this function is used for this conversion.
#'
#' During calculation of gene similarity, genes should be mapped to the relevant GO category. When these two genes could both be annotated to GO terms,
#' 'list of 2 genes reduced to 2' would be shown and then gene similarity is calculated. However, when none or just one of the genes could be annotated to
#' GO terms, it is showed that 'list of 2 genes reduced to 1' or 'list of 2 genes reduced to 0', and then an Error indicates that the gene similarity could not
#' be calculated, and then NA is returned. The average of gene similarity is calculated with NA omitted.
#'
#' @seealso \code{\link{ts.connetion}}, \code{\link[GOSim]{getGeneSim}}.
#'
#' @examples
#' res<-so.rules(bin2,org2,symbol=TRUE,row.g=TRUE,num_gene=20,supp=0.3, conf=0.8,maxl=3, minl=2)
#' head(res);dim(res)
#' g.similarity(res)
#'
#' @references
#' 1. Schlicker, A., et al., A new measure for functional similarity of gene products based on Gene Ontology. BMC Bioinformatics, 2006. 7: p. 302.
#'
#' 2. Frohlich, H., et al., GOSim--an R-package for computation of information theoretic GO similarities between terms and gene products. BMC Bioinformatics, 2007. 8: p. 166.
#'
#' 3. Carlson, M., org.Hs.eg.db: Genome wide annotation for Human. R Package Version 3.1.2, 2015.

g.similarity<-function(matrix_all, symbol=TRUE){

	for (pkg in c('GOSim','tcltk')){
		if(requireNamespace(pkg,quietly=TRUE)==FALSE){
			stop(paste('The ',pkg,' package needed for this function to work. Please install it.'),
           call. = FALSE)
		}
	}

	library('GOSim')
	library('tcltk')
	library('org.Hs.eg.db')
	symbol2id<-as.list(org.Hs.egSYMBOL2EG)
	
	subrules<-matrix_all
	
	lhs<-strsplit(substr(subrules[,'lhs'],2,nchar(as.character(subrules[,'lhs']))-1),',')[[1]]
	rhs<-substr(subrules[,'rhs'],2,nchar(as.character(subrules[,'rhs']))-1)
	
	if (symbol==TRUE){
		genes.id<-unlist(symbol2id[unique(c(lhs,rhs))])
	}else{
		genes.id<-unique(c(lhs,rhs))		
	}

	setOntology(ont = "BP", loadIC=TRUE, DIR=NULL)
	g.num.bp<-getGeneFeatures(genes.id, pca=FALSE, normalization=FALSE, verbose=FALSE)
	genes.id.bp<-genes.id[match(rownames(g.num.bp),genes.id)]
	g.sim.bp<-getGeneSim(genes.id.bp, similarity="funSimMax", similarityTerm="relevance", normalization=TRUE,method='sqrt')

	res.sim<-NULL
	g.sim<-g.sim.bp

	n=nrow(matrix_all)
	pb <- tkProgressBar("Progress","has completed %", 0, 100);
	for (m in 1:n){
		info<- sprintf("has completed %d%%", round(m*100/length(1:n)));
		setTkProgressBar(pb, m*100/length(1:n), sprintf("Progress (%s)", info),info);
		
		tmp.lhs<-strsplit(substr(subrules[m,'lhs'],2,nchar(as.character(subrules[m,'lhs']))-1),',')[[1]]
		tmp.rhs<-substr(subrules[m,'rhs'],2,nchar(as.character(subrules[m,'rhs']))-1)

		Z<-c(tmp.lhs,tmp.rhs)
		A<-tmp.lhs
		C<-tmp.rhs
		
		ind.a<-setdiff(match(unlist(symbol2id[A]),rownames(g.sim)),NA)
		ind.c<-setdiff(match(unlist(symbol2id[C]),rownames(g.sim)),NA)
	
		if (length(ind.a)==1 & length(ind.c)>0){
			tmp.sim<-g.sim[ind.a,ind.c]
		}else if (length(ind.a)==2 & length(ind.c)>0){
			tmp.sim<-max(c(g.sim[ind.a[1],ind.c],g.sim[ind.a[2],ind.c]),na.rm=TRUE)
		}else{
			tmp.sim<-0
		}
	
	res.sim<-c(res.sim,tmp.sim)
	}
	close(pb)
	return(res.sim)
}