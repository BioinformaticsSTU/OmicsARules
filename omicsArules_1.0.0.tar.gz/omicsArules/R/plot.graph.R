#' Graph for association rules
#'
#' This function provides the  visualization of association rules mined in omics dataset.
#'
#' @param rules an object of class matrix.
#' @param main title of the graph plot.
#' @param cex label size.
#'
#' @details This method help to visualize association rules with graph. It uses vertices
#' to represent genes or gene sets (probe or probe set, et al) ,and edges to indicate their
#' relationship in rules. see \code{\link[arulesViz]{plot}} for more details. For clarity,
#' the number of inputted association rules for this visualization should not be too large.
#' Tens of association rules are recommended.
#'
#' @seealso \code{\link[arulesViz]{plot}}, \code{\link{plot.group}}
#'
#' @examples
#' ## rna_esca_symbol: a 0-1 binary dataset contains expression of 100 genes in 184 ESCC patients
#' data(rna_esca_symbol)
#' rules<-oa.rules(rna_esca_symbol,up.lift=2.0,down.lift=1.9)
#' plot.graph(rules)
#'
#' @references
#' 1. Hahsler, M., B. Grun, and K. Hornik, arules - A computational environment for mining association rules and frequent item sets. Journal of Statistical Software, 2005. 14(15).

plot.graph=function(matrix_all, num=50, order="lamda3"){
	for (pkg in c('igraph')){
		if(requireNamespace(pkg,quietly=TRUE)==FALSE){
			stop(paste('The ',pkg,' package needed for this function to work. Please install it.'),
           call. = FALSE)
		}
	}
	library(igraph)
	
	if(length(which(c("supp", "conf", "lift", "lamda3")==order))==0)
	{
		stop("Parameter order error!");
	}
	
	if(nrow(matrix_all)<num){
		num=nrow(matrix_all);
	}
	
	if(order=="supp"){
		matrix_all=matrix_all[order(matrix_all[,3]),];
	}
	if(order=="conf"){
		matrix_all=matrix_all[order(matrix_all[,4]),];
	}
	if(order=="lift"){
		matrix_all=matrix_all[order(matrix_all[,5]),];
	}
	if(order=="lamda3"){
		matrix_all=matrix_all[order(as.double(matrix_all[,6])),];
	}

	matrix_all=matrix_all[order(as.double(matrix_all[,order])),];
	
	matrix_net=matrix_all[1:num,];
	lhs_net=matrix_net[,1];
	rhs_net=matrix_net[,2];
	left_net=NULL;
	right_net=NULL;
	for(i in 1:num){
		len_lhs=nchar(as.character(matrix_net[i,1]));
		part_lhs=substr(as.character(matrix_net[i,1]), 2, len_lhs-1);
		arr_lhs=strsplit(part_lhs, ",")[[1]];
		len_arr_lhs=length(arr_lhs);
		#
		len_rhs=nchar(as.character(matrix_net[i,2]));
		part_rhs=substr(as.character(matrix_net[i,2]), 2, len_rhs-1);
		arr_rhs=strsplit(part_rhs, ",")[[1]];

		if(len_arr_lhs==1){
			left_net=c(left_net,arr_lhs[1]);
			right_net=c(right_net, arr_rhs[1]);
		}else{
			left_net=c(left_net,arr_lhs[1]);
			left_net=c(left_net,arr_lhs[2]);
			right_net=c(right_net, arr_rhs[1]);
			right_net=c(right_net, arr_rhs[1]);
		}
	}

	relations=data.frame(from=left_net, to=right_net)
	g <- graph_from_data_frame(relations, directed=TRUE);

	#pdf("network.pdf")
	plot(g, layout = layout.fruchterman.reingold, vertex.size=5, vertex.shape='circle', vertex.label.cex=0.8, vertex.label.color='black', vertex.color="#326996", edge.arrow.size = 0.5, main="network");
	#dev.off()


}
