#' Applying Apriori for mining association rules particularly for one single omic data containing continuous variables
#'
#' Disease initiation and progression often result from multiple aberrations at multiple regulation dimensions.
#' The co-occurrence pattern among significantly hyper(hypo)-methlylated genes or differentially 
#' expressed genes often imply potential mechanistic connections.In data mining field, the frequently
#' co-occurring items (called frequent item sets) and their associated relationship can be efficiently mined
#' via Apriori algorithm. Originated from market basket data analysis, association rules is a popular and
#' well established method for discovering strong relationship between frequent items. Here, so.rules employs
#' the Apriori algorithm to mining association rules in omics datasets. OmicsARules specially aimed at omics data
#' containing continuous variables, and further embedded a new rule-interestingness measure, Lamda3, to evaluate 
#' the association rules for identifying biologically significant patterns.
#'
#' @param bin a 0-1 binary matrix or data.frame, where 1 reflects dysregulation of genes in tumors or other samples.
#' @param org the original dataset containing continous variables, corresponding the bin dataset before dichotomization. 
#' @param symbol logical. If TRUE, variables are gene symbols; otherwise, entrez id.
#' @param row.g logical. If row indicates gene or probe or other variable?
#' @param supp a numeric value for the minimal support of an gene set (default: 0.3), see \code{\link[arules]{apriori}}.
#' @param conf a numeric value for the minimal confidence of rules (default: 0.8). For frequent genesets it is set to NA. see \code{\link[arules]{apriori}}.
#' @param up.lift a numeric value giving the upper limit of lift of rules (default: 2).
#' @param down.lift a numeric value giving the down limit of lift of rules (default: 1.2).
#' @param maxl an integer value no more then three for the maximal number of genes per geneset. A larger value of maxl resules in time-consuming process (default: 3 items).
#' 	see \code{\link[arules]{apriori}}.
#' @param minl an integer value for the minimal number of geness per geneset (default: 1 item). see \code{\link[arules]{apriori}}.
#' @return an object of class rules.
#' @details This function primarily calls the Apriori algorithm embeded in R-package 'arules' \code{\link[arules]{apriori}}, which calls the C implementation of the
#' 	Apriori algorithm by Christian Borgelt.
#' 	Here, \code{\link{so.rules}} is applied to one omics data for mining association rules, and another new rule-interestingness measure, Lamda3, is calculated.
#' 	For instance, one of association rules, R: {X => Y} is assumed, where X is a single gene or a set of genes on the left hand side (LHS) of this rule, and Y is a single
#' 	gene on the right hand side (RHS) of this rule.
#'
#' Lamda3 was defined as the ratio of the association strength between genes separately on the LHS and the RHS to the average association strength between the gene(s) 
#' on the LHS and others in the matrix except for that one on the RHS. Before calculating, samples (transactions) are devided into three parts: the first part (M1) contains samples 
#' with genes in X and Y to be 1; the second part (M2)indicates samples with genes in X and Y to be 0; and the third part includes samples having inconsistent changes of these 
#' two (or three) genes in this rule. The association strength is reflected by the log10-transformed P values (logP) retrieved from the correlation analyses.
#'  
#' \emph{lamda3}: (logP between X and Y in samples of M1 + logP between X and Y in samples of M2)/
#' (median logP between X and others but not Y in samples of M1 + median logP between X and others but not Y in samples of M2)
#'
#' 	Support of an itemset X is defined as the proportion of genes in the data set which contain the geneset.
#'
#' 	\emph{supp}: supp(X)=the number of samples containing dysregulation of X / the sample size.
#'   supp(R)=supp(X U Y)=the number of samples containing dysregulation of both X and Y / the sample size.
#'
#'  Confidence can be interpreted as an estimate of the probability P(Y|X) of finding the RHS of the rule in omics under the condition that these genesets also contain the LHS.
#'
#'  \emph{conf}: conf(R)=supp(X U Y) / supp(X).
#'
#'  Lift is another practical solution to narrow down the number of rules, in the situation of too many association rules found satisfying the support and confidence constraints.
#'  Lift can be interpreted as the deviation of the support of the whole rule from the support expected under independence given the supports of the LHS and the RHS.
#'
#' 	\emph{lift}: lift(R)=supp(X U Y) / (supp(X) * supp(Y)).
#'  See \code{\link[arules]{apriori}} for more details.
#'
#' @note The Apriori algorithm only creats one gene in the RHS. If minl is 1, then rules with only one gene like R: {} => {Y} could be created.
#' 	That means at the given confidence (supp(R)=conf(R),and lift=1, actually), no matter what other genes are involved, the gene Y is supposed to appear.
#' 	If the mininum supp and/or mininum conf is chosen too low, an extremely large genesets/rules are tried to generated by this algorithm, which asks for
#'  a major expenditure of time and memory usage, not nessary most of the time. To prevent this, the user should first choose the appropriate supp
#'  and conf to replace the default values before running this algorithm. See \code{\link[arules]{apriori}} for more details.
#'
#' @examples
#' ## bin2, org2: namely a 0-1 binary dataset and the corresponding original data containing continous values 
#' assessing expression of 100 genes in 184 ESCC tumors and 11 normal tissues
#' res<-so.rules(bin2,org2,symbol=TRUE,row.g=TRUE,num_gene=20, supp=0.3, conf=0.8,maxl=3, minl=2)
#' res
#'
#' @references
#' 1. Hahsler, M., B. Grun, and K. Hornik, arules - A computational environment for mining association rules and frequent item sets. Journal of Statistical Software, 2005. 14(15).
#'
#' 2. Agrawal, R., T. Imielinski, and A. Swami, Mining association rules between sets of items in large databases. Proceedings of the 1993 ACM SIGMOD International Conference on Management of Data, 1993: p. 207-216.
#'
#' 3. Brin, S., et al., Dynamic itemset counting and implication rules for market basket data. Proceedings of the ACM SIGMOD International Conference on Management of Data, 1997: p. 255-264.
#'
#' 4. Pasquier, N., et al., Closed Set Based Discovery of Small Covers for Association Rules. Networking & Information Systems, 1999. 3(2): p. 349-377.
#'
#' 5. Zaki, M.J., et al., Parallel Algorithms for Discovery of Association Rules. Data Mining and Knowledge Discovery, 1997: p. 343-373.


so.rules=function(bin, org, symbol=TRUE, row.g=TRUE, method="median", num_gene=50, supp=0.3, conf=0.8, up.lift=2, down.lift=1.2, maxl=3, minl=1){

	for (pkg in c('arules', 'org.Hs.eg.db', 'GOSim')){
		if(requireNamespace(pkg,quietly=TRUE)==FALSE){
			stop(paste('The ',pkg,' package needed for this function to work. Please install it.'),
           call. = FALSE);
		}
	}

	if (row.g==TRUE){
		rna=bin[1:num_gene,]
	}else if (row.g==FALSE){
		rna=t(bin)[1:num_gene,]
	}else{
		stop('Error: row.g should be logical')
	}
	
	##convert symbol to entrezid
	if (symbol==TRUE){
		library('org.Hs.eg.db')
		symbol2id<-as.list(org.Hs.egSYMBOL2EG)
		genes.id<-unlist(symbol2id[rownames(rna)])
	}else{
		genes.id<-rownames(rna)
	}

	##calculate the whole gene similarity among genes included in the rules
	library('GOSim')
	setOntology(ont = "BP", loadIC=TRUE, DIR=NULL)
	g.num.bp<-getGeneFeatures(genes.id, pca=FALSE, normalization=FALSE, verbose=FALSE)
	
	if (symbol==TRUE){
		genes.id.bp<-genes.id[match(rownames(g.num.bp),as.numeric(genes.id))]
		syms.bp<-names(genes.id.bp)
		rna.t<-rna[match(syms.bp,rownames(rna)),]
		rna<-na.omit(rna.t)
	}else{
		genes.id.bp<-genes.id[match(rownames(g.num.bp),as.numeric(genes.id))]
		rna.t<-rna[match(genes.id.bp,rownames(rna)),]
		rna<-na.omit(rna.t)
	}
	
	##finding rules
	library("arules", warn.conflicts=FALSE)
	data.trans<-as(t(rna),'transactions');
	rules<-apriori(data.trans,parameter = list(support = supp, confidence = conf, maxlen=maxl, minlen=minl));

	rules<-arules::subset(rules,lift>=down.lift & lift<=up.lift)
	rules.2<-inspect(rules);
	subrules<-rules.2;

	#######################calculate the new measure###################
	##cbind wcs and genes coexpression
	##读入RNAseqV2之前的数据
	if (row.g==TRUE){
		rna.org=org
	}else if (row.g==FALSE){
		rna.org=t(org)
	}else{
		stop('Error: row.g should be logical')
	}
	
	subrna.org<-rna.org[match(rownames(rna),rownames(rna.org)),match(colnames(rna),colnames(rna.org))]
	expr<-subrna.org

	my<-matrix(0,nrow=nrow(rules.2),ncol=4)  ##sgs: support based on gene similarity
	colnames(my)<-c('support','confidence','lift','lamda3');
	matrix_all<-matrix(0,nrow=nrow(rules.2),ncol=6);
	colnames(matrix_all)<-c('lhs','rhs','support','confidence','lift','lamda3');

	for (m in 1:nrow(rules.2)){
		##calculate wcs and wcc,rule Z: A-C
		tmp.lhs<-strsplit(substr(rules.2[m,'lhs'],2,nchar(as.character(rules.2[m,'lhs']))-1),',')[[1]]
		tmp.rhs<-substr(rules.2[m,'rhs'],2,nchar(as.character(rules.2[m,'rhs']))-1)
		Z<-c(tmp.lhs,tmp.rhs)


		##embed genes coexpression,calculate wcs and wcc,rule Z: A-C
		if (length(tmp.lhs)==1 & length(tmp.rhs)>0){
			samples.ac<-which(rna[which(rownames(rna)==tmp.lhs),]==1 & rna[which(rownames(rna)==tmp.rhs),]==1)
			samples..<-	which(rna[which(rownames(rna)==tmp.lhs),]==0 & rna[which(rownames(rna)==tmp.rhs),]==0)

			lhs.ac<-as.numeric(expr[which(rownames(expr)==tmp.lhs),samples.ac])
			lhs..<-as.numeric(expr[which(rownames(expr)==tmp.lhs),samples..])	

			rhs.ac<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples.ac])
			rhs..<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples..])
					
			others.ac<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2]),samples.ac]
			others..<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2]),samples..]		
			##cal tmp.lamda
			if (length(samples.ac)<=2 & length(samples..)>2){
				
				p.z..<-abs(log10(cor.test(lhs..,rhs..)$p.value));
				
				p.others..<-NULL;
				for(i in 1:nrow(others..)){
					p.others..<-c(p.others..,log10(cor.test(lhs..,as.numeric(others..[i,]))$p.value))
				}
				if(method=="median"){
					p.others..<-median(abs(p.others..))
				}else if(method=="mean"){
					p.others..<-mean(abs(p.others..))
				}
				
				if (p.z..==0){
					p.z..=abs(log10((10)^(-50)));
				}
				
				if (p.others..==0){
					p.others..=abs(log10((10)^(-50)));
				}
				
				tmp.lamda<-p.z../p.others..;
				
			}else if (length(samples.ac)>2 & length(samples..)<=2){
			
				p.z.ac<-abs(log10(cor.test(lhs.ac,rhs.ac)$p.value));
			
				p.others.ac<-NULL;
				for (i in 1:nrow(others.ac)){
					p.others.ac<-c(p.others.ac,log10(cor.test(lhs.ac,as.numeric(others.ac[i,]))$p.value))
				}
				if(method=="median"){
					p.others.ac<-median(abs(p.others.ac))
				}else if(method=="mean"){
					p.others.ac<-mean(abs(p.others.ac))
				}
				
				if (p.z.ac==0){
					p.z.ac=abs(log10((10)^(-50)));
				}
				if (p.others.ac==0){
					p.others.ac=abs(log10((10)^(-50)));
				}
				
				tmp.lamda<-p.z.ac/p.others.ac;
				
			}else if (length(samples.ac)<=2 & length(samples..)<=2){
				tmp.lamda<-0;
			}else{

				p.z.ac<-abs(log10(cor.test(lhs.ac,rhs.ac)$p.value));
				p.z..<-abs(log10(cor.test(lhs..,rhs..)$p.value));

				p.others.ac<-NULL
				for (i in 1:nrow(others.ac)){
					p.others.ac<-c(p.others.ac,log10(cor.test(lhs.ac,as.numeric(others.ac[i,]))$p.value));
				}
				if(method=="median"){
					p.others.ac<-median(abs(p.others.ac))
				}else if(method=="mean"){
					p.others.ac<-mean(abs(p.others.ac))
				}
				
				p.others..<-NULL
				for (i in 1:nrow(others..)){
					p.others..<-c(p.others..,log10(cor.test(lhs..,as.numeric(others..[i,]))$p.value))
				}
				if(method=="median"){
					p.others..<-median(abs(p.others..))
				}else if(method=="mean"){
					p.others..<-mean(abs(p.others..))
				}
				
				if (p.z.ac==0){
					p.z.ac=abs(log10((10)^(-50)));
				}
				if (p.others.ac==0){
					p.others.ac=abs(log10((10)^(-50)));
				}
				if (p.z..==0){
					p.z..=abs(log10((10)^(-50)));
				}
				if (p.others..==0){
					p.others..=abs(log10((10)^(-50)));
				}
				
				tmp.lamda<-(p.z.ac+p.z..)/(p.others.ac+p.others..);
			}
		}else if (length(tmp.lhs)==2 & length(tmp.rhs)>0){

			samples.abc<-which(rna[which(rownames(rna)==tmp.lhs[1]),]==1 & rna[which(rownames(rna)==tmp.lhs[2]),]==1 & rna[which(rownames(rna)==tmp.rhs),]==1)
			samples..<-	which(rna[which(rownames(rna)==tmp.lhs[1]),]==0 & rna[which(rownames(rna)==tmp.lhs[2]),]==0 & rna[which(rownames(rna)==tmp.rhs),]==0)

			lhs1.abc<-as.numeric(expr[which(rownames(expr)==tmp.lhs[1]),samples.abc])
			lhs2.abc<-as.numeric(expr[which(rownames(expr)==tmp.lhs[2]),samples.abc])
			lhs1..<-as.numeric(expr[which(rownames(expr)==tmp.lhs[1]),samples..])
			lhs2..<-as.numeric(expr[which(rownames(expr)==tmp.lhs[2]),samples..])
			rhs.abc<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples.abc]);
			rhs..<-as.numeric(expr[which(rownames(expr)==tmp.rhs),samples..]);
			others.abc<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2] | rownames(expr)==Z[3]),samples.abc]
			others..<-expr[-which(rownames(expr)==Z[1] | rownames(expr)==Z[2] | rownames(expr)==Z[3]),samples..]

			##cal tmp.lamda
			if (length(samples.abc)<=2 & length(samples..)>2){

				p.z1..<-abs(log10(cor.test(lhs1..,rhs..)$p.value));		
				p.z2..<-abs(log10(cor.test(lhs2..,rhs..)$p.value))
				
				p.others1..<-NULL
				for (i in 1:nrow(others..)){
					p.others1..<-c(p.others1..,log10(cor.test(lhs1..,as.numeric(others..[i,]))$p.value))			
				}
				if(method=="median"){
					p.others1..<-median(abs(p.others1..));
				}else if(method=="mean"){
					p.others1..<-mean(abs(p.others1..));
				}
				
				p.others2..<-NULL
				for (i in 1:nrow(others..)){
					p.others2..<-c(p.others2..,log10(cor.test(lhs2..,as.numeric(others..[i,]))$p.value))
				}
				if(method=="median"){
					p.others2..<-median(abs(p.others2..));
				}else if(method=="mean"){
					p.others2..<-mean(abs(p.others2..));
				}
				
				if (p.z1..==0){
					p.z1..=abs(log10((10)^(-50)));
				}
				
				if (p.others1..==0){
					p.others1..=abs(log10((10)^(-50)));
				}
				
				if (p.z2..==0){
					p.z2..=abs(log10((10)^(-50)));
				}
				
				if (p.others2..==0){
					p.others2..=abs(log10((10)^(-50)));
				}
				
				tmp.lamda<-(p.z1..+p.z2..)/(p.others1..+p.others2..)
			
			}else if (length(samples.abc)>2 & length(samples..)<=2){
				
				p.z1.abc<-abs(log10(cor.test(lhs1.abc,rhs.abc)$p.value))
				p.z2.abc<-abs(log10(cor.test(lhs2.abc,rhs.abc)$p.value))

				p.others1.abc<-NULL;
				for (i in 1:nrow(others.abc)){
					p.others1.abc<-c(p.others1.abc,log10(cor.test(lhs1.abc,as.numeric(others.abc[i,]))$p.value))
				}
				if(method=="median"){
					p.others1.abc<-median(abs(p.others1.abc));
				}else if(method=="mean"){
					p.others1.abc<-mean(abs(p.others1.abc));
				}

				p.others2.abc<-NULL
				for (i in 1:nrow(others.abc)){
					p.others2.abc<-c(p.others2.abc,log10(cor.test(lhs2.abc,as.numeric(others.abc[i,]))$p.value))
				}
				if(method=="median"){
					p.others2.abc<-median(abs(p.others2.abc))	
				}else if(method=="mean"){
					p.others2.abc<-mean(abs(p.others2.abc))	
				}

				if (p.z1.abc==0){
					p.z1.abc=abs(log10((10)^(-50)));
				}
				if (p.others1.abc==0){
					p.others1.abc=abs(log10((10)^(-50)));
				}
				if (p.z2.abc==0){
					p.z2.abc=abs(log10((10)^(-50)));
				}
				if (p.others2.abc==0){
					p.others2.abc=abs(log10((10)^(-50)));
				}
				
				tmp.lamda<-(p.z1.abc+p.z2.abc)/(p.others1.abc+p.others2.abc)
			
			}else if (length(samples.abc)<=2 & length(samples..)<=2){
				tmp.lamda<-0;
			}else{

				p.z1.abc<-abs(log10(cor.test(lhs1.abc,rhs.abc)$p.value))
				p.z2.abc<-abs(log10(cor.test(lhs2.abc,rhs.abc)$p.value))

				p.z1..<-abs(log10(cor.test(lhs1..,rhs..)$p.value));			
				p.z2..<-abs(log10(cor.test(lhs2..,rhs..)$p.value))
				
				p.others1.abc<-NULL;
				for (i in 1:nrow(others.abc)){
					p.others1.abc<-c(p.others1.abc,log10(cor.test(lhs1.abc,as.numeric(others.abc[i,]))$p.value))
				}
				if(method=="median"){
					p.others1.abc<-median(abs(p.others1.abc));
				}else if(method=="mean"){
					p.others1.abc<-mean(abs(p.others1.abc));
				}
				
				p.others2.abc<-NULL;
				for (i in 1:nrow(others..)){
					p.others2.abc<-c(p.others2.abc,log10(cor.test(lhs2.abc,as.numeric(others.abc[i,]))$p.value))
				}
				if(method=="median"){
					p.others2.abc<-median(abs(p.others2.abc));
				}else if(method=="mean"){
					p.others2.abc<-mean(abs(p.others2.abc));
				}
				p.others1..<-NULL;
				for (i in 1:nrow(others..)){
					p.others1..<-c(p.others1..,log10(cor.test(lhs1..,as.numeric(others..[i,]))$p.value))				
				}	
				if(method=="median"){
					p.others1..<-median(abs(p.others1..));
				}else if(method=="mean"){
					p.others1..<-mean(abs(p.others1..));
				}
				p.others2..<-NULL
				for (i in 1:nrow(others..)){
				p.others2..<-c(p.others2..,log10(cor.test(lhs2..,as.numeric(others..[i,]))$p.value))
				}
				if(method=="median"){
					p.others2..<-median(abs(p.others2..))	
				}else if(method=="mean"){
					p.others2..<-mean(abs(p.others2..))	
				}
				if (p.z1.abc==0){
					p.z1.abc=abs(log10((10)^(-50)));
				}
				if (p.z2.abc==0){
					p.z2.abc=abs(log10((10)^(-50)));
				}
				if (p.z1..==0){
					p.z1..=abs(log10((10)^(-50)));
				}
				if (p.z2..==0){
					p.z2..=abs(log10((10)^(-50)));
				}
				if (p.others1.abc==0){
					p.others1.abc=abs(log10((10)^(-50)));
				}
				if (p.others2.abc==0){
					p.others2.abc=abs(log10((10)^(-50)));
				}
				if (p.others1..==0){
					p.others1..=abs(log10((10)^(-50)));
				}
				if (p.others2..==0){
					p.others2..=abs(log10((10)^(-50)));
				}

				tmp.lamda<-(p.z1.abc+p.z2.abc+p.z1..+p.z2..)/(p.others1.abc+p.others2.abc+p.others1..+p.others2..)
			}
		}else if (length(tmp.lhs)==0 | length(tmp.rhs)==0){
			tmp.lamda<-0
		}
		my[m,]<-c(rules.2[m,'support'],rules.2[m,'confidence'],rules.2[m,'lift'],tmp.lamda);
		matrix_all[m,]=c(as.character(rules.2[m,'lhs']), as.character(rules.2[m,'rhs']), my[m,]);
	}

	return(matrix_all);
}


