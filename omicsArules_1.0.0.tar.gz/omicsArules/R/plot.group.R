#' Group association rules
#'
#' This function groups the association rules mined from omics data and provides the visualization.
#'
#' @param rules an object of class matrix.
#' @param methods any function computing a scalar from a vector (e.g., min, mean, median (default), sum, max) and reordering the balloons in the plot.
#' @param k number of antecedent groups (default: 20)
#'
#' @details To visualize the grouped matrix, a balloon plot was created with antecedent groups as columns (left-hand side, LHS) and consequents as rows (right-hand side, RHS).
#' The idea is that genes/probes on LHS of several rules, which are statistically dependent on the same gene/probe on RHS, are supposed to be similar and thus can be grouped together.
#' see \code{\link[arulesViz]{plot}} for more details.
#'
#' @seealso \code{\link[arulesViz]{plot}}, \code{\link{plot.graph}}
#'
#' @examples
#' ## rna_esca_symbol: a 0-1 binary dataset contains expression of 100 genes in 184 ESCC patients
#' data(rna_esca_symbol)
#' rules<-oa.rules(rna_esca_symbol,up.lift=2.0,down.lift=1.8)
#' plot.group(rules)

#' @references
#' 1. Hahsler, M., B. Grun, and K. Hornik, arules - A computational environment for mining association rules and frequent item sets. Journal of Statistical Software, 2005. 14(15).

plot.group<-function(matrix_all, num=50, order="lamda3"){
	for (pkg in c('ggplot2')){
		if(requireNamespace(pkg,quietly=TRUE)==FALSE){
			stop(paste('The ',pkg,' package needed for this function to work. Please install it.'),
           call. = FALSE)
		}
	}
	library(ggplot2)
	
	if(length(which(c("supp", "conf", "lift", "lamda3")==order))==0)
	{
		stop("Parameter order error!");
	}
	
	if(order=="supp"){
		matrix_all=matrix_all[order(matrix_all[,3]),];
	}
	if(order=="conf"){
		matrix_all=matrix_all[order(matrix_all[,4]),];
	}
	if(order=="lift"){
		matrix_all=matrix_all[order(matrix_all[,5]),];
	}
	if(order=="lamda3"){
		matrix_all=matrix_all[order(as.double(matrix_all[,6])),];
	}
	
	matrix_all=matrix_all[order(as.double(matrix_all[,order])),];
	
	if(num>nrow(matrix_all)){
		num=nrow(matrix_all);
	}
	matrix_part=matrix_all[1:num,];
	lhs=matrix_part[,1];
	rhs=matrix_part[,2];
	supp=as.double(matrix_part[,3]);
	lamda3=as.double(matrix_part[,6]);
	
	size=lamda3;
	color=supp;
	
	#pdf("scatter.pdf");
	ggplot(data=as.data.frame(matrix_part), aes(x = lhs, y = rhs, size = size, colour=color))+geom_point(alpha = .5)+ theme(axis.text.x=element_text(angle=90));
	#dev.off();

}
