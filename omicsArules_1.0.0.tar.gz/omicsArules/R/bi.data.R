#' Convert continuous variables into 0-1 dichotomous variables
#'
#' Given a matrix with continous values, \code{bi.data} convert the entry into a 0-1 dichotomous variable
#' according to a certain cutoff value. This helps the user to get his dataset transformed and suitable
#' for association rules analysis, \code{\link{oa.rules}}, easily and simply. Of course, you can transform
#' your dataset by your own method, and process to next step directly.
#'
#' @param file a matrix or data frame, with continous variables.
#' @param row.g logical. If row indicates gene or probe or other variable?
#' @param geneSel logical. Should these genes or probes (other variables) be sorted? If TRUE, \code{\link[base]{order}} is called.
#' @param score if 'geneSel' is TRUE, the user should simultaneously import a numeric vector here to reflect
#' 	the importance of these genes or probes (or other variables). The length of this vector shoul be equal to
#' 	the number of genes/probes (or other variables). Missing values (NA) are put last. See the help for \code{\link[base]{order}}.
#' @param decrease logical. Should the sort be increasing or decreasing?
#' @param indicator NULL or a 0-1 numeric vector. If the gene/probe (other variable) correspone to 1, then these
#' 	entries larger than the cutoff value will be transformed into 1, otherwise, 0 is given. If the gene/probe (other
#' 	variable) corresponse to 0, then these entries less than the cutoff value will be transformed into 1, otherwise,
#' 	 0 is endowed. If NULL (default), the entries of all the genes/probes(other variables) larger than the cutoff value
#' 	should be transformed into 1, or else, 0 is given.
#' @param methods character string specifying the algorithm used to calculate the cutoff value for each gene/probe (other
#' 	 variable). Four methods are optional,namely mean, median, the upper quantile (p25) and the down quantile (p75).
#' @return A matrix or data frame, of which entries are 0-1 dichotomous values.
#' @seealso \code{\link[base]{order}}
#' @examples
#' ## org contains expression of 100 genes in 184 ESCC tumors and 11 noraml tissues 
#' data(org)
#' head(org)
#' bi.data(org)
bi.data<-function(file,row.g=TRUE,geneSel=FALSE,score=NULL,decrease=TRUE,indicator=NULL,methods='mean'){

  if(!is.logical(row.g)){
    stop('Error: row.g should be logical')
  }else if(!is.logical(geneSel)){
    stop('Error: geneSel should be logical')
  }else if(!is.logical(decrease)){
    stop('Error: decrease should be logical')
  }

  library(outliers);

  if (row.g==TRUE){
		file<-file
	}else{
		file<-t(file)
	}

	if (geneSel==TRUE){
	  if(is.null(score)==TRUE){
	    stop('Error:If geneSel is TRUE, order should be called')
	  }
		file<-file[order(as.numeric(score),decreasing=decrease,na.last=TRUE),]
	}else{
		file<-file
	}
	cutoffs=NULL;
	if (methods=='mean'){
		cutoffs<-rowMeans(file)
	}else if (methods=='median'){
		cutoffs<-apply(file,1,function(x) quantile(x)['50%'])
	}else if (methods=='p25'){
		cutoffs<-apply(file,1,function(x) quantile(x)['25%'])
	}else if (methods=='p75'){
		cutoffs<-apply(file,1,function(x) quantile(x)['75%'])
	}else if (methods=='del-outliers'){
		for (i in 1:nrow(file)){
			y<-as.numeric(file[i,])
			x<-y
			out.test<-grubbs.test(y)
			while (out.test$p.value<0.05){
				out.test<-grubbs.test(y)
				tmp.m<-mean(y)
				tmp.index<-which.max(abs(y-tmp.m))
				y<-y[-tmp.index]
				if (length(y)>=1){
					out.test$p.value<-out.test$p.value
				}else{
					out.test$p.value<-1
				}
			}

			if (out.test$p.value==1){
				tmp.index.func<-i
				means.f<-mean(x)
			}else{
				tmp.index.func<-NULL
				means.f<-mean(y)
			}

			cutoffs<-c(cutoffs,means.f)
		}
	}

	binary<-NULL
	if (is.null(indicator)==FALSE){
		for (i in 1:nrow(file)){
			tmp<-rep(0,ncol(file))
			if (indicator[i]==1){
				tmp[which(file[i,]>cutoffs[i])]<-1
			}else if (indicator[i]==0){
				tmp[which(file[i,]<cutoffs[i])]<-1
			}
			binary<-rbind(binary,tmp)
		}
	}else if (is.null(indicator)==TRUE){
		 for (i in 1:nrow(file)){
			tmp<-rep(0,ncol(file))
			tmp[which(file[i,]>cutoffs[i])]<-1
			binary<-rbind(binary,tmp)
			}
	}

	rownames(binary)<-rownames(file)
	colnames(binary)<-colnames(file)

	return(binary)
}



