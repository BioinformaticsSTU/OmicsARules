#' Finding the common rules between two independent sets of association rules
#'
#' It is interesting to discover the mechanistic commonality in pathogenesis of different
#' type of cancers (or other diseases, such as immunologic diseases).So users can use the
#' individual association rules mined from two types of cancers to identify the common
#' association rules.Alternatively, users may address whether there are any associated
#' patterns "conserved" in different regulation level.In this case, users can use individual
#' association rules mined from two types of platfroms (such as transcription level, DNA
#' methylation level, et al.) to discover the common associaiton rules shared across different
#' regulation levels, which usually indicate enforced strong gene regulation
#'
#' @param rules.1 a matrix retrieved from so.rules or mo.rules.
#' @param rules.2 another matrix retrieved from so.rules or mo.rules.
#' @return a set of rules.
#'
#' @seealso \code{\link{so.rules}}
#'
#' @examples
#' res1<-so.rules(bin2,org2,symbol=TRUE,row.g=TRUE,num_gene=20,supp=0.3, conf=0.8,maxl=3, minl=2)
#' head(res1);dim(res1)
#' res2<-so.rules(bin2[10:100,],org2[10:100,],symbol=TRUE,row.g=TRUE,num_gene=40,supp=0.3, conf=0.8,maxl=3, minl=2)
#' head(res2);dim(res2)
#' c.rules(res1,res2)

c.rules<-function(rules.1,rules.2){

	rhs.1<-rules.1[,'rhs']
	lhs.1<-rules.1[,'lhs']
	rhs.2<-rules.2[,'rhs']
	lhs.2<-rules.2[,'lhs']

	lhs.1<-strsplit(substr(lhs.1,2,nchar(lhs.1)-1),',')
	lhs.2<-strsplit(substr(lhs.2,2,nchar(lhs.2)-1),',')
	rhs.1<-unlist(substr(rhs.1,2,nchar(rhs.1)-1))
	rhs.2<-unlist(substr(rhs.2,2,nchar(rhs.2)-1))

	rhs.comm<-intersect(rhs.1,rhs.2)
	index1.comm<-NULL
	index2.comm<-NULL
	for (i in 1:length(rhs.comm)){
		ind.1<-which(rhs.1==rhs.comm[i])
		ind.2<-which(rhs.2==rhs.comm[i])
		tmp.1<-lhs.1[ind.1]
		tmp.2<-lhs.2[ind.2]
		subindex1.comm<-NULL
		subindex2.comm<-NULL
		for (j in 1:length(ind.1)){
			for (h in 1:length(ind.2)){
				tmp<-setequal(unlist(tmp.1[j]),unlist(tmp.2[h]))
				if (tmp==TRUE){
					subindex1.comm<-c(subindex1.comm,ind.1[j])
					subindex2.comm<-c(subindex2.comm,ind.2[h])
				}else{
					subindex1.comm<-c(subindex1.comm,NULL)
					subindex2.comm<-c(subindex2.comm,NULL)
				}

			}
		}
	index1.comm<-c(index1.comm,subindex1.comm)
	index2.comm<-c(index2.comm,subindex2.comm)
	}

	rules.comm<-cbind(rules.1[index1.comm,c('lhs','rhs','support','confidence','lift','lamda')],rules.2[index2.comm,c('lhs','rhs','support','confidence','lift','lamda')])
	colnames(rules.comm)<-c('lhs_1','rhs_1','support_1','confidence_1','lift_1','lamda_1','lhs_2','rhs_2','support_2','confidence_2','lift_2','lamda_2')

	cat('The common rules between these two datasets: ',nrow(rules.comm),' rules\n\n')
	return(rules.comm)
}





